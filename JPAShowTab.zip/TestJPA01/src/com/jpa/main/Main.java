package com.jpa.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Persistence;

import com.jpa.objects.Testtab;

public class Main {

	public static void main(String[] args) {
		EntityManager entityManager = Persistence.createEntityManagerFactory("TestJPA01").createEntityManager();
		List<Testtab> listTest = entityManager.createQuery("select t from Testtab t", Testtab.class).getResultList();
		
		for (Testtab testtab : listTest) {
			System.out.println(testtab);
		}

	}

}
